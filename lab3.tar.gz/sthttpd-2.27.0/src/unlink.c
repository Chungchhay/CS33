#include <unistd.h>
int main() {
  char file[] = "target.txt";
  unlink(file);
  return 0;
}
