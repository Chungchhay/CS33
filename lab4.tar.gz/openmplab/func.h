#include "util.h"

void func0(double *weights, double *arrayX, double *arrayY,
	   int xr, int yr, int n);
void func1(int *seed, int *array, double *arrayX, double *arrayY,
	   double *probability, double *objxy, int *index,
	   int Ones, int iter, int X, int Y, int Z, int n);
void func2(double *weights, double *probability, int n);
void func3(double *arrayX, double *arrayY, double *weights,
	   double *x_e, double *y_e, int n);
void func4(double *u, double u1, int n);
void func5(double *x_j, double *y_j, double *arrayX, double *arrayY,
	   double *weights, double *cfd, double *u, int n);
void filter(int *array, int X, int Y, int Z, int * seed, int N, FILE *ofp);
